from django.urls import path,include
from wishlist import views
urlpatterns = [
path('',views.wishlist,name='wishlist')
]
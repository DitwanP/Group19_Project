from django.shortcuts import render,HttpResponse,redirect,HttpResponseRedirect
from wishlist.models import Wishlist
from Books.models import Book as bookmodel
# change this model to your item model
from django.contrib import messages
# Create your views here.
def wishlist(request):
    if request.method=='POST':
        if request.POST['action']=='makewishlist':

            name=request.POST.get('wishlist_name')
            count_wishlist=Wishlist.objects.filter(user=request.user).count()
            if count_wishlist<3:
                wish_list=Wishlist.objects.create(name=name,user=request.user)
                return redirect('/wishlist')
            else :
                messages.error(request,"Can't Add More Than 3 Wishlists",extra_tags='add_wishlist')
                return redirect('/wishlist') 
        elif request.POST['action']=='transfer_prod_wish':
            
            initial_wish=Wishlist.objects.get(id=request.POST['initial_wish_id'])
            selected_wish=Wishlist.objects.get(id=request.POST['transfer_wishlist_dropdown'])
            selected_prod=bookmodel.objects.get(id=request.POST['selected_book_id'])
            if selected_wish.book.filter(id=request.POST['selected_book_id']).exists():
                messages.error(request,"Product already exists in Destined wishlist!",extra_tags='product_transfer')
                return redirect('/wishlist')
            else:
                selected_wish.book.add(selected_prod)
                initial_wish.book.remove(selected_prod)
                messages.success(request,"Product Transfered !",extra_tags='product_transfer')

                return redirect('/wishlist')

        else:   
            selected_prod_id=request.POST['wish_prod_id']
            selected_wish_id=request.POST['wish_id']
            selected_wish=Wishlist.objects.get(id=selected_wish_id)
            selected_prod=bookmodel.objects.get(id=selected_prod_id)
            selected_wish.book.remove(selected_prod)
            return redirect('/wishlist')



        
    else:
        wish_list=Wishlist.objects.all()
        return render(request,'wishlist.html',{'wishlist':wish_list})
from django.contrib import admin
from wishlist.models import Wishlist
# Register your models here.
admin.site.register(Wishlist)

from django.db import models
from django.contrib.auth.models import User
from Books.models import Book as book_model
# Create your models here.
class Wishlist(models.Model):
    name=models.CharField(max_length=1000)
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    book=models.ManyToManyField(book_model)
from django.shortcuts import render,HttpResponse,redirect,HttpResponseRedirect
from Books.models import Book as bookmodel
# change model according to your item model

from wishlist.models import Wishlist
from django.contrib import messages
# Create your views here.
def itemdetails(request,id):
    if request.method=='POST':
        selected_prod_id=id
        selected_wishlistid=request.POST['wishlistdropdown']
        selected_wish=Wishlist.objects.get(id=selected_wishlistid)
        selected_prod=bookmodel.objects.get(id=selected_prod_id)
        selected_wish.book.add(selected_prod)
        messages.success(request,'Successfully Added Product To WishList')
        return redirect('item_details',id=id)
    else:
        book=bookmodel.objects.get(id=id)
        wishlist=Wishlist.objects.filter(user=request.user)
        return render(request,'item_details.html',{'book':book,'wishes':wishlist})
    
def all_items(request):
        book=bookmodel.objects.all()
        wishlist=Wishlist.objects.filter(user=request.user)
        return render(request,'items.html',{'book':book,'wishes':wishlist})
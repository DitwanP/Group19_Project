from django.contrib import admin
from Books.models import Book as book_model
# Register your models here.

admin.site.register(book_model)

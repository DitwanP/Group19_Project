from django.urls import path,include
from Books import views

urlpatterns = [
    path('',views.all_items,name='all_items'),
    path('item/<int:id>',views.itemdetails,name='item_details')
]
